#include "agreement.h"
#include "uart.h"
#include "io.h"

u8 SMARTMODE = 0;
u8 TEMPTHRESHOLD;

sysData DataBuf = {DATA_HEADH,DATA_HEADL,0,0,0,0,CMDID_UP,0,0,0,0,0,0,0,DATA_END};

void Send_SensorData(u8 _SensorType, u8 _SenserIndex, u8 *_pData)
{
	DataBuf.dataDet.sIndex    = _SenserIndex;
	DataBuf.dataDet.sValue[0] = _pData[0];
	DataBuf.dataDet.sValue[1] = _pData[1];
	DataBuf.dataDet.sValue[2] = _pData[2];
	DataBuf.dataDet.sValue[3] = _pData[3];
	DataBuf.dataDet.sType		  = _SensorType;
	
	uartSendData(DataBuf.dataArry, DATA_LENGTH);
}

void agreementParse(u8 *str)
{
	if(str[0] == DATA_HEADH && str[1] == DATA_HEADL && str[5] == DATA_END)
	{
		if(str[9] == CMDID_MODE) //����ģʽ
		{
			SMARTMODE = str[14];
			TEMPTHRESHOLD = str[13];		
		}
		
		if(str[9] == CMDID_DOWN) //�·�����ָ��
		{
			switch (str[8]) //��ͬ������
			{
				case SENSOR_FAN://����
					if(str[14])
						FAN_ON();
					else
						FAN_OFF();
					break;
				case SENSOR_LAMP://�ƹ�
					//do somthing
					break;
				default:
					break;
			}
		}
	}
}

