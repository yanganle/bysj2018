#ifndef __UART2_H__
#define __UART2_H__

#include <reg52.h> 

#define Baudrate2		19200	
#define MAIN_Fosc		12000000L	

#define BUFFER_LENGTH 127

extern u8 uart2RxSta;
extern u8 UART2_RX_BUF[BUFFER_LENGTH];
extern u8 uart2RxCount;
extern u8 uart2RxTimeOut;
extern u8 flag_uart2_rx;

void Uart2Init(void);
void SendData(u8 dat);
void SendString2(char *s);
void clearBuf2(void);


#endif
