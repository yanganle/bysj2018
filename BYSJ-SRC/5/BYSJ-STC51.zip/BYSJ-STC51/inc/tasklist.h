#ifndef __TASK_LIST_H__
#define __TASK_LIST_H__

#include <reg52.h> 
#include <stdio.h> 

void MyTask_One(void);
void MyTask_Two(void);
void MyTask_Three(void);
void MyTask_Four(void);

#endif
