#ifndef __DELAY_H__
#define __DELAY_H__

//#include <reg52.h>
//#include <stdio.h>
//#include <intrins.h>

//void delay_ms(u16 ms);

#endif
